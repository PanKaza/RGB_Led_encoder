#undef GLOBAL
#ifdef __REDGREENLEDCOLOR_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __REDGREENLEDCOLOR_H
#define __REDGREENLEDCOLOR_H

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"

extern DAC_HandleTypeDef  DacRedHandle;
extern DAC_HandleTypeDef  DacGreenHandle;

extern void DAC_Red_Config(void);
extern void DAC_Green_Config(void); // red and green shares DAC3

extern void COMP_Red_Config(void);
extern void COMP_Green_Config(void);

extern void DAC_Red_DeConfig(void);
extern void DAC_Green_DeConfig(void); // red and green shares DAC3 , DAC3 has 2 channels and must work together for this reason  

extern void COMP_Red_DeConfig(void);
extern void COMP_Green_DeConfig(void);

extern void OPAMP_Red_Config(void);
extern void OPAMP_Green_Config(void);
extern void OPAMP_Red_DeConfig(void);
extern void OPAMP_Green_DeConfig(void);


#ifdef __cplusplus
}
#endif

#endif /* __REDGREENLEDCOLOR_H */


/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/
