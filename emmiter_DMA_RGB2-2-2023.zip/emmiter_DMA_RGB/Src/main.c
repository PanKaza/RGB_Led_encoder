/**
 ******************************************************************************
 * @file    Demonstrations/Src/main.c
 * @author  MCD Application Team
 * @brief   Main program body
 ******************************************************************************
 * @attention
 ******************************************************************************
 */
#define __MAIN_C

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "controlerRGB.h"
#include "8b_10b_encoder.h"

//There libs are requipred mainly for testing
#include <stdlib.h>
#include "printf.h"

UART_HandleTypeDef huart3;/////////////

/*Function prototypes -----------------------------------------------*/
static void SystemClock_Config(void);
static void MX_USART3_UART_Init(void);
void HAL_HRTIM_CounterResetCallback(HRTIM_HandleTypeDef * hhrtim,uint32_t TimerIdx);
void next_dma(void);
void fill_array(void);
void print_waves(void);


/*This is our global variables .These cannot be coved elsewhere because the
 interrupts are happening our of the program's execution time HAL_HRTIM_CounterResetCallback*/
int batch_size;
int offset;
int red_rd,green_rd,blue_rd;
int iterations;
int batch_remainder;
uint8_t *src_red,*src_green,*src_blue;
uint32_t *wave_red,*wave_green,*wave_blue;
uint32_t *temp_wave_red,*temp_wave_green,*temp_wave_blue;
uint32_t *decoded_data;

int main(void)
{
  
  HAL_Init();
  //GPIO_InitStructure.Speed  HRTIM_OUTPUTSET_TIMPER ,,PERIOD
  // Configure the System clock to have a frequency of 170 MHz
  SystemClock_Config();
  MX_USART3_UART_Init();

  int size,i;

  uint8_t data[24];//change this number to adjust data size

  int elements=sizeof(data)/sizeof(uint8_t);
  int remainder=elements%3;

  red_rd=-1;
  green_rd=-1;
  blue_rd=-1;
  offset=0;
  batch_size=3;//number of data size per batch
  
//generate random data for our array
  srand(time(NULL));
  //for(i=0;i<elements;i++)
  //{
  // data[i]=rand()%256;
  //}

  //test all possible values 0xff
  for (i=0;i<=23;i++)
    {
        data[i]=i;
    }
//calculate the size of our red green blue arrays
  if(remainder==0)
  {
    size=(elements/3);
  }
  else
  {
    size=(elements/3+1);
  }
  iterations=size/batch_size;
  batch_remainder=size%batch_size;
//set arrays
  src_red=(uint8_t*)malloc(sizeof(uint8_t)*size);
  src_green=(uint8_t*)malloc(sizeof(uint8_t)*size);
  src_blue=(uint8_t*)malloc(sizeof(uint8_t)*size);
  //+1 refers to the last custom element of array that is 0x20 a.k.a. led turn off
  wave_red=(uint32_t*)malloc(sizeof(uint32_t)*(batch_size*10+1));
  wave_green=(uint32_t*)malloc(sizeof(uint32_t)*(batch_size*10+1));
  wave_blue=(uint32_t*)malloc(sizeof(uint32_t)*(batch_size*10+1));

  temp_wave_red=(uint32_t*)malloc(sizeof(uint32_t)*batch_size*10);
  temp_wave_green=(uint32_t*)malloc(sizeof(uint32_t)*batch_size*10);
  temp_wave_blue=(uint32_t*)malloc(sizeof(uint32_t)*batch_size*10);

  decoded_data=(uint32_t*)malloc(sizeof(uint32_t)*size);

//split our data to even color groups
  for(i = 0; i < size-1 ; i++){
    src_red[i] = data[i*3];
    src_green[i] =data[i*3+1];
    src_blue[i] = data[i*3+2];
  }

  if(remainder==0){
    src_red[size-1] = data[elements-3];
    src_green[size-1] =data[elements-2];
    src_blue[size-1] =data[elements-1];
  }
  else if(remainder==1)
  {
    src_red[size-1] = data[elements-1];
    src_green[size-1] =0;
    src_blue[size-1] =0;
  }
  else if(remainder==2)
  {
    src_red[size-1] = data[elements-2];
    src_green[size-1] =data[elements-1];
    src_blue[size-1] =0;
  }
  

  printf("Main\n");
//calculate the next dma pass it to the led and recalculate the next one
  MX_DMA_Init();
  next_dma();
  fill_array();
  next_dma();

  Demo_LedWhite(wave_red,wave_green,wave_blue,batch_size*10+1);
}


void print_waves(void)
//print all the rgb waves via printf 
{
  int i=0;
  printf("\n\nRed wave:");
  for (i = 0; i < batch_size * 10+1; i++)
  {
    printf("%ld,", wave_red[i]);
  }

  printf("\nGreen wave:");
  for (i = 0; i < batch_size * 10+1; i++)
  {
    printf("%ld,", wave_green[i]);
  }

  printf("\nBlue wave:");
  for (i = 0; i < batch_size * 10+1; i++)
  {
    printf("%ld,", wave_blue[i]);
  }
}

void fill_array(void)
//This method passes each temp color array to the main array of rgb
{
  int i;
  for(i=0;i<batch_size*10;i++)
  {
    wave_red[i]=temp_wave_red[i];
    wave_green[i]=temp_wave_green[i];
    wave_blue[i]=temp_wave_blue[i];
  }
  //fill the last element of each led with 0
  wave_red[batch_size*10]=0x20;
  wave_green[batch_size*10]=0x20;
  wave_blue[batch_size*10]=0x20;
  //print_waves();
}

void next_dma(void)
//This method calculates the next transmitable waves of rgb
{
  if(iterations>0)
  {
    encode8b_10b(&red_rd, batch_size, &src_red[offset], temp_wave_red, decoded_data);
    encode8b_10b(&green_rd, batch_size, &src_green[offset], temp_wave_green, decoded_data);
    encode8b_10b(&blue_rd, batch_size, &src_blue[offset], temp_wave_blue, decoded_data);
    iterations=iterations-1;
    
  }
  else{
    //this else part is filling the rest of the batch 
    //with the coresponding zeros depending on the current rd of each led
    
    if(batch_remainder!=0)
    {
      encode8b_10b(&red_rd, batch_remainder, &src_red[offset],temp_wave_red, decoded_data);
      encode8b_10b(&green_rd, batch_remainder, &src_green[offset], temp_wave_green, decoded_data);
      encode8b_10b(&blue_rd, batch_remainder, &src_blue[offset], temp_wave_blue, decoded_data);

      uint32_t zero_encoded_rd0[]={0xffff,0x20,0x20,0xffff,0xffff,0xffff,0x20,0xffff,0x20,0x20};//1001110100 for rd=-1
      uint32_t zero_encoded_rd1[]={0x20,0xffff,0xffff,0x20,0x20,0x20,0xffff,0x20,0xffff,0xffff};//1001110100 for rd=1

      int i=0;
      for(i=0;i<(batch_size-batch_remainder);i++)
      {
        int j=0;
        ///// red
        if(red_rd==1){
          for(j=0;j<10;j++)
          {
            temp_wave_red[(batch_remainder+i)*10+j]=zero_encoded_rd1[j];
          }
        }
        else
        {
          for(j=0;j<10;j++)
          {
            temp_wave_red[(batch_remainder+i)*10+j]=zero_encoded_rd0[j];
          }
        }
        /////////////green 
        if(green_rd==1){
          for(j=0;j<10;j++)
          {
            temp_wave_green[(batch_remainder+i)*10+j]=zero_encoded_rd1[j];
          }
        }
        else
        {
          for(j=0;j<10;j++)
          {
            temp_wave_green[(batch_remainder+i)*10+j]=zero_encoded_rd0[j];
          }
        }
        ///blue
        if(blue_rd==1){
          for(j=0;j<10;j++)
          {
            temp_wave_blue[(batch_remainder+i)*10+j]=zero_encoded_rd1[j];
          }
        }
        else
        {
          for(j=0;j<10;j++)
          {
            temp_wave_blue[(batch_remainder+i)*10+j]=zero_encoded_rd0[j];
          }
        }
      }
      batch_remainder=0;
    }
    else
    {
      printf("Success!!!\n\n");
      exit(0);
    }
    
  }
  offset =offset+ batch_size;
  
}

void HAL_HRTIM_CounterResetCallback(HRTIM_HandleTypeDef * hhrtim,uint32_t TimerIdx)
/*This method is called each time a loop is made foe each led light.
Warning: this method is normally called 3 times from each color but now its only called
once from red (see controllerrgb 229)*/
{
  print_waves();
  HAL_HRTIM_WaveformCounterStop_DMA(hhrtim, HRTIM_TIMERID_TIMER_E | HRTIM_TIMERID_TIMER_F | HRTIM_TIMERID_TIMER_A);//lock counter
  
  fill_array();
  
  HAL_HRTIM_WaveformCounterStart_DMA(hhrtim, HRTIM_TIMERID_TIMER_E | HRTIM_TIMERID_TIMER_F | HRTIM_TIMERID_TIMER_A);//unlock counter
  next_dma();

}

/**
 * @brief  System Clock Configuration
 *         The system Clock is configured as follow :
 *            System Clock source            = PLL (HSI)
 *            SYSCLK(Hz)                     = 170000000
 *            HCLK(Hz)                       = 170000000
 *            AHB Prescaler                  = 1
 *            APB1 Prescaler                 = 1
 *            APB2 Prescaler                 = 1
 *            HSI Frequency(Hz)              = 16000000
 *            PLL_M                          = 4
 *            PLL_N                          = 85
 *            PLL_P                          = 10
 *            PLL_Q                          = 2
 *            PLL_R                          = 2
 *            Flash Latency(WS)              = 8
 * @param  None
 * @retval None
 */
static void SystemClock_Config(void)
{
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  // Enable voltage range 1 boost mode for frequency above 150 Mhz
  __HAL_RCC_PWR_CLK_ENABLE();
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);
  __HAL_RCC_PWR_CLK_DISABLE();

  // Activate PLL with HSI as source
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV10;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    // Initialization Error
    while (1)
      ;
  }

  // Select PLL as system clock source and configure the HCLK, PCLK1 and PCLK2 clocks dividers
  RCC_ClkInitStruct.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK |
                                 RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_8) != HAL_OK)
  {
    /* Initialization Error */
    while (1)
      ;
  }

   /** Initializes the peripherals clocks
   */
   PeriphClkInit.PeriphClockSelection =RCC_PERIPHCLK_RTC|RCC_PERIPHCLK_ADC12|RCC_PERIPHCLK_USART3;
   PeriphClkInit.Adc12ClockSelection = RCC_ADC12CLKSOURCE_PLL;
   PeriphClkInit.RTCClockSelection = RCC_RTCCLKSOURCE_LSI;
   PeriphClkInit.Usart3ClockSelection = RCC_USART3CLKSOURCE_PCLK1;
   if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
   {
     Error_Handler();
   }
}

#ifdef USE_FULL_ASSERT

/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */

  /* Infinite loop */
  while (1)
  {
  }
}

#endif

/**
 * @brief  Error handler
 * @param  None
 * @retval None
 */
void Error_Handler(void)
{
  while (1)
  {
    /* blink red led in case of error */
    HAL_Delay(100);
    HAL_GPIO_TogglePin(LED_RED_PORT, LED_RED_PIN);
  }
}

static void MX_USART3_UART_Init(void)
{

  /* USER CODE BEGIN USART3_Init 0 */

  /* USER CODE END USART3_Init 0 */

  /* USER CODE BEGIN USART3_Init 1 */

  /* USER CODE END USART3_Init 1 */
  huart3.Instance = USART3;
  huart3.Init.BaudRate = 115200;
  huart3.Init.WordLength = UART_WORDLENGTH_8B;
  huart3.Init.StopBits = UART_STOPBITS_1;
  huart3.Init.Parity = UART_PARITY_NONE;
  huart3.Init.Mode = UART_MODE_TX_RX;
  huart3.Init.HwFlowCtl = UART_HWCONTROL_NONE;
  huart3.Init.OverSampling = UART_OVERSAMPLING_16;
  huart3.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
  huart3.Init.ClockPrescaler = UART_PRESCALER_DIV1;
  huart3.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
  if (HAL_UART_Init(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetTxFifoThreshold(&huart3, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_SetRxFifoThreshold(&huart3, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
  {
    Error_Handler();
  }
  if (HAL_UARTEx_DisableFifoMode(&huart3) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN USART3_Init 2 */

  /* USER CODE END USART3_Init 2 */

}