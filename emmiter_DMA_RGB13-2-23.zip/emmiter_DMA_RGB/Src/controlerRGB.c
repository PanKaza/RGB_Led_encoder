#define __CONTROLER_C


#include "main.h"
#include "defs.h"
#include "redgreenRGB.h"
#include "blueRGB.h"
#include "controlerRGB.h"
#include "printf.h"


typedef enum {
  PHASE_RISING = 0,
  PHASE_FALLING,
  PHASE_OFF,
  MAX_PHASE
}LED_PHASE_TypeDef;

#define  RED   0
#define  GREEN 1
#define  BLUE  2




static __IO uint32_t  MaxVoltageSenseRGB[3]; 

static const uint32_t hrtim_output[3] = {HRTIM_OUTPUT_TF1, HRTIM_OUTPUT_TE1, HRTIM_OUTPUT_TA1};

static int32_t GlobalBrigthness_1000;  // Range [0 .. 1000]

// Due to color sensitivity, each color must be weighted 
static uint32_t RedWeight;
static uint32_t GreenWeight;
static uint32_t BlueWeight;


DMA_HandleTypeDef    hdma_hrtim_ch1;
DMA_HandleTypeDef    hdma_hrtim_ch5;
DMA_HandleTypeDef    hdma_hrtim_ch3;

// prototypes

static void RGBLed_Init(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size);
static void RGBLed_DeInit(void);

static void HRTIM_Config(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size);
static void HRTIM_DeConfig(void);




void Demo_LedWhite(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size); // white spectrum with rgb combination 


/**
  * @brief  RGB led initialization: DAC, COMP, HRTIM
  * @param  None
  * @retval None
  */
static void RGBLed_Init(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size)
{
  // DAC Configuration 
  __HAL_RCC_DAC1_CLK_ENABLE();
  __HAL_RCC_DAC3_CLK_ENABLE();
  DAC_Red_Config();   // red   is on DAC3,        channel 2, triggered by HRTIM F. For debug (on in code) , output goes through OPAMP3 to PB1 (analog mode)
  DAC_Green_Config(); // green is on DAC3,        channel 1, triggered by HRTIM E. For debug (on in code) , output goes through OPAMP1 to PA2 (analog mode)
  DAC_Blue_Config();  // blue  is on DAC1 (slow), channel 1, triggered by HRTIM A. For debug (off by default see warning), output is also connected to PB0 (analog mode)

#ifdef DEBUG_FAST_DAC
  // OPAMP Configuration for DAC3 channel1/2 debug as there is no GPIO output for DAC3 
  OPAMP_Red_Config();
  OPAMP_Green_Config();
#endif

#ifdef DEBUG_SLOW_DAC
  GPIO_InitTypeDef GPIO_InitStructure;
  // Debug DAC1_CH1 on PB0 
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitStructure.Pin  =  GPIO_PIN_4;
  GPIO_InitStructure.Mode = GPIO_MODE_ANALOG;
  GPIO_InitStructure.Pull = GPIO_NOPULL;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);
#endif


  // COMP Configuration 
  COMP_Red_Config();
  COMP_Green_Config();
  COMP_Blue_Config();

  // HRTIM Configuration 
  HRTIM_Config(wave_red,wave_green,wave_blue,batch_size);
}

/**
  * @brief  led deinitialization: DAC, COMP, HRTIM
  * @param  None
  * @retval None
  */
static void RGBLed_DeInit(void)
{
  // HRTIM Deconfiguration 
 HRTIM_DeConfig();

#ifdef DEBUG_FAST_DAC
  // OPAMP Deconfiguration 
  OPAMP_Red_DeConfig();
  OPAMP_Green_DeConfig();

  // Deinit GPIO PA4 
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4);
#endif

  // DAC Deconfiguration 
  DAC_Red_DeConfig();
  DAC_Green_DeConfig();
  DAC_Blue_DeConfig();

  __HAL_RCC_DAC1_CLK_DISABLE();
  __HAL_RCC_DAC3_CLK_DISABLE();

  // COMP Deconfiguration 
  COMP_Red_DeConfig();
  COMP_Green_DeConfig();
  COMP_Blue_DeConfig();

}

void MX_DMA_Init(void)
{

  // DMA controller clock enable 
  __HAL_RCC_DMAMUX1_CLK_ENABLE();
  __HAL_RCC_DMA1_CLK_ENABLE();

  // DMA interrupt init 
  // DMA1_Channel1_IRQn interrupt configuration 
  // for green
  //HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);  //DMA1_Channel1_IRQn
  //HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn); 

  // for green
  //HAL_NVIC_SetPriority(DMA1_Channel5_IRQn, 0, 0);  //DMA1_Channel2_IRQn
  //HAL_NVIC_EnableIRQ(DMA1_Channel5_IRQn); 

  // for blue
  //HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);  //DMA1_Channel3_IRQn
  //HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn); 

}

void HAL_HRTIM_MspInit(HRTIM_HandleTypeDef * hrtimHandle)
{

  // for red led

    hdma_hrtim_ch1.Instance = DMA1_Channel1; // DMA1_Channel1
    hdma_hrtim_ch1.Init.Request = DMA_REQUEST_HRTIM1_F; //DMA_REQUEST_HRTIM1_F
    hdma_hrtim_ch1.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch1.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch1.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    //hdma_hrtim_ch1.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch1.Init.Mode=DMA_NORMAL;
    hdma_hrtim_ch1.Init.Priority = DMA_PRIORITY_HIGH;


    __HAL_LINKDMA(hrtimHandle,hdmaTimerF,hdma_hrtim_ch1); // for timer F
    if (HAL_DMA_Init(&hdma_hrtim_ch1) != HAL_OK)
    {
      Error_Handler();
    }
    HAL_NVIC_SetPriority(DMA1_Channel1_IRQn, 0, 0);  //DMA1_Channel1_IRQn
    HAL_NVIC_EnableIRQ(DMA1_Channel1_IRQn); 


  // for green led

    hdma_hrtim_ch5.Instance = DMA1_Channel5; // DMA1_Channel5
    hdma_hrtim_ch5.Init.Request = DMA_REQUEST_HRTIM1_E; //DMA_REQUEST_HRTIM1_E
    hdma_hrtim_ch5.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch5.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch5.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch5.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch5.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    //hdma_hrtim_ch5.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch5.Init.Mode=DMA_NORMAL;
    hdma_hrtim_ch5.Init.Priority = DMA_PRIORITY_HIGH;


    __HAL_LINKDMA(hrtimHandle,hdmaTimerE,hdma_hrtim_ch5); // for timer E

    if (HAL_DMA_Init(&hdma_hrtim_ch5) != HAL_OK)
    {
      Error_Handler();
    }
    HAL_NVIC_SetPriority(DMA1_Channel5_IRQn, 0, 0);  //DMA1_Channel2_IRQn
    //HAL_NVIC_EnableIRQ(DMA1_Channel5_IRQn); 


  // for green led

    hdma_hrtim_ch3.Instance = DMA1_Channel3; // DMA1_Channel3
    hdma_hrtim_ch3.Init.Request = DMA_REQUEST_HRTIM1_A; //DMA_REQUEST_HRTIM1_A
    hdma_hrtim_ch3.Init.Direction = DMA_MEMORY_TO_PERIPH;
    hdma_hrtim_ch3.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_hrtim_ch3.Init.MemInc = DMA_MINC_ENABLE;
    hdma_hrtim_ch3.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
    hdma_hrtim_ch3.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
    //hdma_hrtim_ch3.Init.Mode = DMA_CIRCULAR;
    hdma_hrtim_ch3.Init.Mode=DMA_NORMAL;
    hdma_hrtim_ch3.Init.Priority = DMA_PRIORITY_LOW;

    __HAL_LINKDMA(hrtimHandle,hdmaTimerA,hdma_hrtim_ch3); // for timer A

    if (HAL_DMA_Init(&hdma_hrtim_ch3) != HAL_OK)
    {
      Error_Handler();
    }
    HAL_NVIC_SetPriority(DMA1_Channel3_IRQn, 0, 0);  //DMA1_Channel3_IRQn
    //HAL_NVIC_EnableIRQ(DMA1_Channel3_IRQn); 
}

void HAL_HRTIM_MspDeInit(HRTIM_HandleTypeDef * hrtimHandle)
{
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerF); // for timer F
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerE); // for timer E
    HAL_DMA_DeInit(hrtimHandle->hdmaTimerA); // for timer A
}



void Demo_LedWhite(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size)
{
  // Initialize LedWhite demo 
  RGBLed_Init(wave_red,wave_green,wave_blue,batch_size);

  GlobalBrigthness_1000 = 700;

  // White balance. Could be adjusted to get cool/warm white 
  RedWeight   =  100;  // Aris: strangelly this doesn't work when set to 65
  GreenWeight =  100;
  BlueWeight =  80;


  //
  // Start HRTIM waveforms generation                        
  //

  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[RED]) != HAL_OK)
  {
    Error_Handler();
  }
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[GREEN]) != HAL_OK)
  {
    Error_Handler();
  }
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, hrtim_output[BLUE]) != HAL_OK)
  {
    Error_Handler();
  }
  
  // For small brightness (under threshold), adjust sawtooth level 
  // After threshold, sawtooth level stays at its maximum 
  //
  // Configure Sawtooth waveform generation for all RGB leds 
  //
  MaxVoltageSenseRGB[RED]   = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * RedWeight)   / (1000 * BRIGHTNESS_THRESHOLD);
  MaxVoltageSenseRGB[GREEN] = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * GreenWeight)   / (1000 * BRIGHTNESS_THRESHOLD);
  MaxVoltageSenseRGB[BLUE] = (MAX_DAC_SAW_PEAK * GlobalBrigthness_1000 * BlueWeight)   / (1000 * BRIGHTNESS_THRESHOLD);
  // Max current sense should be in the middle of saw tooth slope range 
  HAL_DACEx_SawtoothWaveGenerate(&DacRedHandle, DAC_CHANNEL_2, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[RED]   * 4096) / 3300 ,  FAST_DAC_STEP); //3300
  HAL_DACEx_SawtoothWaveGenerate(&DacGreenHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[GREEN]   * 4096) / 3300 ,  FAST_DAC_STEP);
  HAL_DACEx_SawtoothWaveGenerate(&DacBlueHandle, DAC_CHANNEL_1, DAC_SAWTOOTH_POLARITY_DECREMENT, (MaxVoltageSenseRGB[BLUE]   * 4096) / 3300 ,  SLOW_DAC_STEP);

  // Idle loop


  //HAL_DeInit();

  // Deinitialize 
  while(1)
  ;

  RGBLed_DeInit();

}

/**
* @brief  HRTIM configuration
* @param  None
* @retval None
*/
static void HRTIM_Config(uint32_t wave_red[],uint32_t wave_green[],uint32_t wave_blue[],int batch_size)
{
  int DMA_SIZE=batch_size;

  GPIO_InitTypeDef          GPIO_InitStructure;
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureRed; // red
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureGreen; // green
  HRTIM_CompareCfgTypeDef   HRTIM_CompareStructureBlue; // blue
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureRed; // red
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureGreen; // green
  HRTIM_EventCfgTypeDef     HRTIM_ExternalEventStructureBlue; // blue
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureRed; // red
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureGreen; // green
  HRTIM_OutputCfgTypeDef    HRTIM_OutputStructureBlue; // blue
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureRed; // red 
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureGreen; // green
  HRTIM_TimeBaseCfgTypeDef  HRTIM_TimeBaseStructureBlue; // blue
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureRed; // red
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureGreen; // green
  HRTIM_TimerCfgTypeDef     HRTIM_TimerWaveStructureBlue; // blue
  // These are common for red, green, and blue
  HRTIM_TimerCtlTypeDef     HRTIM_TimerCtl;
  HRTIM_TimerEventFilteringCfgTypeDef HRTIM_TimerEventFilteringCfg; 
  

  // Enable HRTIM clock 
  __HAL_RCC_HRTIM1_CLK_ENABLE();


  // The following calls HAL_HRTIM_MspInit which sets up DMA channels etc.
  HrtimHandle.Instance = HRTIM1;
  HAL_HRTIM_Init(&HrtimHandle);

  // HRTIM initialization startup 
  if(HAL_HRTIM_DLLCalibrationStart(&HrtimHandle, HRTIM_CALIBRATIONRATE_3) != HAL_OK)
  {
    Error_Handler();
  }

  if(HAL_HRTIM_PollForDLLCalibration(&HrtimHandle, HAL_MAX_DELAY) != HAL_OK)
  {
    Error_Handler();
  }

  


  // ---------------------------- HRTIM_F FOR RED LED  --------------------------------------------------
  // HRTIM output channel configuration : HRTIM_CHF1 (Buck drive red led) / PC6  
  // set on timer period event (HRTIM_OUTPUTSET_TIMPER)  or CMP1 (HRTIM_OUTPUTSET_TIMCMP1)
  // reset from COMP2 
  //

  // GPIOC Pin 6 init
  __HAL_RCC_GPIOC_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_6;
  GPIO_InitStructure.Mode      = GPIO_MODE_AF_PP;
  GPIO_InitStructure.Speed     = GPIO_SPEED_FREQ_HIGH;
  GPIO_InitStructure.Pull      = GPIO_NOPULL;
  GPIO_InitStructure.Alternate = GPIO_AF13_HRTIM1;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);


  // Configure the output features 
  // Output is SET (HIGH) when either: 
  //  -- TIMPER - the period event, i.e. timer starts from 0
  //  -- TIMCMP1 - Comparator 1 (of timer F), is reached. THIS IS REMOVED FOR DMA-fed inputs. It doesn't seem to be usefull anyway.
  // and RESET (LOW) when either:
  //  -- EEV_1 - external event 1. This is when the analog comparator (which compares the DAC sawtooth signal with the sense resistor voltage) trips
  //  -- TIMCP4 - Comparator 4 value (of timer F) is reached. This is fed by DMA data. When low (0x20), the led stays off. When set to 0xFFFF, EEV_1 does the actual resetting
  HRTIM_OutputStructureRed.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  // HRTIM_OutputStructureRed.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1;
  HRTIM_OutputStructureRed.SetSource             = HRTIM_OUTPUTSET_TIMPER;
  HRTIM_OutputStructureRed.ResetSource           = HRTIM_OUTPUTRESET_EEV_1 | HRTIM_OUTPUTSET_TIMCMP4;
  HRTIM_OutputStructureRed.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureRed.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureRed.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureRed.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureRed.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                    HRTIM_OUTPUT_TF1, &HRTIM_OutputStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure HRTIM1_TIMF waveform 
  //  This, among other things, sets up the DMA:
  // -DMA_RST -- A DMA request is made when the counter is reset (the period event)
  // -The data from DMA is stored to CMP3 register of TIMER F
  // -The data source (memory) is at &wave_red
  // - DMASize -- How many data transfers to do 
  HRTIM_TimerWaveStructureRed.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE);  // Don't cause interrupts
  HRTIM_TimerWaveStructureRed.DMARequests           = HRTIM_TIM_DMA_RST; // make a DMA request when the timer is reset (@ period event)
  HRTIM_TimerWaveStructureRed.DMASrcAddress         = (int)wave_red; //(int)&wave_red;
  HRTIM_TimerWaveStructureRed.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_F)].CMP4xR);
  HRTIM_TimerWaveStructureRed.DMASize               = DMA_SIZE; //8
  HRTIM_TimerWaveStructureRed.HalfModeEnable        = HRTIM_HALFMODE_DISABLED; 
  HRTIM_TimerWaveStructureRed.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureRed.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureRed.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureRed.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureRed.PreloadEnable         = HRTIM_PRELOAD_DISABLED; // Aris: It doesn't work when preload is enabled.
  HRTIM_TimerWaveStructureRed.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureRed.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureRed.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureRed.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureRed.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureRed.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureRed.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureRed.DelayedProtectionMode = HRTIM_TIMER_F_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureRed.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureRed.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_F;
  HRTIM_TimerWaveStructureRed.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureRed.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureRed.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;
  
  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimerWaveStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // CMP2 is used to trigger the DAC to output the next step of the sawtooth
  //   the DAC is triggered every HRTIM_CompareStructure.CompareValue counter steps even though the counter is not reset.
  HRTIM_CompareStructureRed.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureRed.AutoDelayedTimeout = 0;
  HRTIM_CompareStructureRed.CompareValue       = (PERIOD/(FAST_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // the basic TIMER F counter period setup
  HRTIM_TimeBaseStructureRed.Period            = PERIOD; // 1 period = 4 us = 100% time 
  HRTIM_TimeBaseStructureRed.RepetitionCounter = 0x00;// 0x00
  HRTIM_TimeBaseStructureRed.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL32;//dont change this you shall ruin interrupts
  
  HRTIM_TimeBaseStructureRed.Mode              = HRTIM_MODE_CONTINUOUS;

  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimeBaseStructureRed) != HAL_OK)
  {
    Error_Handler();
  }



  // TIMER F CMP3 is used to ignore (blank in their terminology) any early reset event from the analog comparator 
  //     early in the counter cycle (at the first 1/17th of the 4us period)
  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 

  // This is a configuration for the external even to reset the output (PC6) from the analog comparator (COMP2)
  // Configure External Event Source 1 
  HRTIM_ExternalEventStructureRed.Source      = HRTIM_EEV1SRC_COMP2_OUT;
  HRTIM_ExternalEventStructureRed.Polarity    = HRTIM_EVENTPOLARITY_HIGH;
  HRTIM_ExternalEventStructureRed.Sensitivity = HRTIM_EVENTSENSITIVITY_LEVEL;
  HRTIM_ExternalEventStructureRed.FastMode    = HRTIM_EVENTFASTMODE_ENABLE;
  HRTIM_ExternalEventStructureRed.Filter      = HRTIM_EVENTFILTER_NONE;

  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_1, &HRTIM_ExternalEventStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // ARIS: TIMER F CMP3 is used to ignore (blank in their terminology) any early reset event from the analog comparator 
  //     early in the counter cycle (at the first 1/17th of the 4us period)
  /* Compare unit 3 is used to blank COMP event at the beginning of the period */
  /* This is to avoid being reset by spurious glitch */
  HRTIM_TimerEventFilteringCfg.Filter = HRTIM_TIMEEVFLT_BLANKINGCMP3;
  HRTIM_TimerEventFilteringCfg.Latch = HRTIM_TIMEVENTLATCH_DISABLED;
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, HRTIM_EVENT_1, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }

  HRTIM_CompareStructureRed.CompareValue       = 0x500; // ARIS: = 1280 periods of 5.44GHz clock = 0.235us  = 1/17th of the counter period (4us)
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                     HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  
  // CMP1 is used to set the output high. However at the new period it is also set: see HRTIM_OUTPUTSET_TIMPER above
  //     it might be that HRTIM_OUTPUTSET_TIMPER was not required and is a mistake
  //     or a safety feature, if we get a reset event which is not "blanked" by CMP3 above?
  // Compare unit 1 is used to force output of HRTIM a few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 
  HRTIM_CompareStructureRed.CompareValue       = 0x100;
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                      HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  /* Aris: Added CMP4 to test if fixing it to 0, keeps the led off. 
         This does not work on its own. because the CMP1 also sets the output at 0x100. The CMP3 is "blanking" external reset event only so it should not affect this.
         When I remove CMP1 from the output set options, or set its CompareValue to 0, it appears to work.
   **** VERY IMPORTANT *****
         However, CMP4 needs to be 20 in order for the LED to be off. (HRTIM is run at max frequency and the manual says some of the LSBs of the comparators are not taken into account at the comparison at such high frequencies). I do see a small glitch in the mosfet gate, but the photodiode should not be able to pick it up.
  */
  HRTIM_CompareStructureRed.CompareValue       = 0x20; // led appears off
  //HRTIM_CompareStructure.CompareValue       = 0xFFFF; // led appears on up to the current limit
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F,
                                     HRTIM_COMPAREUNIT_4, &HRTIM_CompareStructureRed) != HAL_OK)
  {
    Error_Handler();
  }

  // ARIS: start producing the output waveform (PC6) which drives the MOSFET
  /* Enable the TF1 output */
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, HRTIM_OUTPUT_TF1) != HAL_OK)
  {
    Error_Handler();
  }


  // DAC trigers: 
  //  reset (start from initial value) - when the counter is reset / rolls over
  //  step - based on CMP2 - set above
  // Configure DAC Reset and Step signal for sawtooth generation 
  HRTIM_TimerCtl.UpDownMode = HRTIM_TIMERUPDOWNMODE_UP;
  HRTIM_TimerCtl.TrigHalf = HRTIM_TIMERTRIGHALF_DISABLED;
  HRTIM_TimerCtl.GreaterCMP3 = HRTIM_TIMERGTCMP3_EQUAL;
  HRTIM_TimerCtl.GreaterCMP1 = HRTIM_TIMERGTCMP1_EQUAL;
                                       //!< the trigger is generated on counter reset or roll-over event 
  HRTIM_TimerCtl.DualChannelDacReset = HRTIM_TIMER_DCDR_COUNTER;
                                      //!< the trigger is generated on compare 2 event 
  HRTIM_TimerCtl.DualChannelDacStep = HRTIM_TIMER_DCDS_CMP2;
  HRTIM_TimerCtl.DualChannelDacEnable = HRTIM_TIMER_DCDE_ENABLED;   // generate both the DAC reset and step trigger events

  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_F, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }
  

  // --------------------  CODE FOR HRTIM_E FOR GREEN LED
  //
  // Configure HRTIM TIM E                                                         
  // HRTIM output channel configuration : HRTIM_CHE1 (Buck drive green led) / PC8  
  // These are similar to HRTIM F above. Some structs defined above are re-used here
  //     e.g. the DAC trigger stuff.
  //
  GPIO_InitStructure.Pin       = GPIO_PIN_8;
  GPIO_InitStructure.Alternate = GPIO_AF3_HRTIM1;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStructure);

  // Configure the output features 
  HRTIM_OutputStructureGreen.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  //HRTIM_OutputStructureGreen.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1;
  HRTIM_OutputStructureGreen.SetSource             = HRTIM_OUTPUTSET_TIMPER;
  HRTIM_OutputStructureGreen.ResetSource           = HRTIM_OUTPUTRESET_EEV_5 | HRTIM_OUTPUTSET_TIMCMP4;  // EEV5 -> COMP3(analog)  TIMCMP4
  HRTIM_OutputStructureGreen.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureGreen.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureGreen.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureGreen.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureGreen.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  // Configure the output features 
  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                    HRTIM_OUTPUT_TE1, &HRTIM_OutputStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }


  // Configure HRTIM1_TIM_E waveform 
  // this must be general config stuff. Nothing interesting here
  HRTIM_TimerWaveStructureGreen.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE);
  HRTIM_TimerWaveStructureGreen.DMARequests           = HRTIM_TIM_DMA_RST;
  HRTIM_TimerWaveStructureGreen.DMASrcAddress         = (int)wave_green;
  HRTIM_TimerWaveStructureGreen.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_E)].CMP4xR);
  HRTIM_TimerWaveStructureGreen.DMASize               = DMA_SIZE;
  HRTIM_TimerWaveStructureGreen.HalfModeEnable        = HRTIM_HALFMODE_DISABLED; 
  HRTIM_TimerWaveStructureGreen.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureGreen.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureGreen.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureGreen.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureGreen.PreloadEnable         = HRTIM_PRELOAD_DISABLED;
  HRTIM_TimerWaveStructureGreen.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureGreen.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureGreen.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureGreen.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureGreen.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureGreen.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureGreen.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureGreen.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureGreen.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureGreen.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureGreen.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;
  HRTIM_TimerWaveStructureGreen.DelayedProtectionMode = HRTIM_TIMER_D_E_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureGreen.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_E;
  
  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimerWaveStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // CMP2 triggers DAC sawtooth step
  HRTIM_CompareStructureGreen.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureGreen.AutoDelayedTimeout = 0;
  HRTIM_CompareStructureGreen.CompareValue       = (PERIOD/(FAST_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // the basic TIMER E counter period setup
  HRTIM_TimeBaseStructureGreen.Period            = PERIOD; // 1 period = 4 us = 100% time 
  HRTIM_TimeBaseStructureGreen.RepetitionCounter = 0x00;
  HRTIM_TimeBaseStructureGreen.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL32;
  HRTIM_TimeBaseStructureGreen.Mode              = HRTIM_MODE_CONTINUOUS;
  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimeBaseStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }


  // Configure External Event Source 5
  HRTIM_ExternalEventStructureGreen.Source      = HRTIM_EEV5SRC_COMP3_OUT;
  HRTIM_ExternalEventStructureGreen.Polarity    = HRTIM_EVENTPOLARITY_HIGH;
  HRTIM_ExternalEventStructureGreen.Sensitivity = HRTIM_EVENTSENSITIVITY_LEVEL;
  HRTIM_ExternalEventStructureGreen.FastMode    = HRTIM_EVENTFASTMODE_ENABLE;
  HRTIM_ExternalEventStructureGreen.Filter      = HRTIM_EVENTFILTER_NONE;
  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_5, &HRTIM_ExternalEventStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure blanking on COMP event to avoid spurious glitch. HRTIM_TimerEventFilteringCfg is setup in "red" above.
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, HRTIM_EVENT_5, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 
  HRTIM_CompareStructureGreen.CompareValue       = 0x500; // ARIS: = 1280 periods of 5.44GHz clock = 0.235us  = 1/17th of the counter period (4us)
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                    HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }
  

  // Compare unit 1 is used to force output of HRTIM few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 
  HRTIM_CompareStructureGreen.CompareValue       = 0x100;
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                     HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  HRTIM_CompareStructureGreen.CompareValue       = 0x20; // led appears off
  //HRTIM_CompareStructure.CompareValue       = 0xFFFF; // led appears on
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E,
                                     HRTIM_COMPAREUNIT_4, &HRTIM_CompareStructureGreen) != HAL_OK)
  {
    Error_Handler();
  }

  // Enable the TE1 output 
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, HRTIM_OUTPUT_TE1) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure DAC Reset and Step signal for sawtooth generation. HRTIM_TimerCtl is set in the config code for RED above
  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_E, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }


  // ------------------------------------- CODE FOR HRTIM_A FOR BLUE LED
  //
  // Configure HRTIM TIM A                                                        
  // HRTIM output channel configuration : HRTIM_CHA1 (Buck drive blue led) / PA8  
  //
  // GPIOA Peripheral clock enable 
  __HAL_RCC_GPIOA_CLK_ENABLE();
  GPIO_InitStructure.Pin       = GPIO_PIN_8;
  GPIO_InitStructure.Alternate = GPIO_AF13_HRTIM1;
  HAL_GPIO_Init(GPIOA, &GPIO_InitStructure);

  HRTIM_OutputStructureBlue.Polarity              = HRTIM_OUTPUTPOLARITY_HIGH;
  //HRTIM_OutputStructureBlue.SetSource             = HRTIM_OUTPUTSET_TIMPER | HRTIM_OUTPUTSET_TIMCMP1;
  HRTIM_OutputStructureBlue.SetSource             = HRTIM_OUTPUTSET_TIMPER;
  HRTIM_OutputStructureBlue.ResetSource           = HRTIM_OUTPUTRESET_EEV_2 | HRTIM_OUTPUTSET_TIMCMP4;
  HRTIM_OutputStructureBlue.IdleMode              = HRTIM_OUTPUTIDLEMODE_IDLE;
  HRTIM_OutputStructureBlue.IdleLevel             = HRTIM_OUTPUTIDLELEVEL_INACTIVE;
  HRTIM_OutputStructureBlue.FaultLevel            = HRTIM_OUTPUTFAULTLEVEL_NONE;
  HRTIM_OutputStructureBlue.ChopperModeEnable     = HRTIM_OUTPUTCHOPPERMODE_DISABLED;
  HRTIM_OutputStructureBlue.BurstModeEntryDelayed = HRTIM_OUTPUTBURSTMODEENTRY_REGULAR;

  // Configure the output features 
  if(HAL_HRTIM_WaveformOutputConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                    HRTIM_OUTPUT_TA1, &HRTIM_OutputStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure HRTIM1_TIM_A waveform 
  HRTIM_TimerWaveStructureBlue.InterruptRequests     = (HRTIM_MASTER_IT_NONE | HRTIM_TIM_IT_NONE);
  HRTIM_TimerWaveStructureBlue.DMARequests           = HRTIM_TIM_DMA_RST;
  HRTIM_TimerWaveStructureBlue.DMASrcAddress         = (int)wave_blue;
  HRTIM_TimerWaveStructureBlue.DMADstAddress         = (int)&(HrtimHandle.Instance->sTimerxRegs[(HRTIM_TIMERINDEX_TIMER_A)].CMP4xR);
  HRTIM_TimerWaveStructureBlue.DMASize               = DMA_SIZE; // 8
  HRTIM_TimerWaveStructureBlue.HalfModeEnable        = HRTIM_HALFMODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.InterleavedMode       = HRTIM_INTERLEAVED_MODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.StartOnSync           = HRTIM_SYNCSTART_DISABLED;
  HRTIM_TimerWaveStructureBlue.ResetOnSync           = HRTIM_SYNCRESET_DISABLED;
  HRTIM_TimerWaveStructureBlue.DACSynchro            = HRTIM_DACSYNC_NONE;
  HRTIM_TimerWaveStructureBlue.PreloadEnable         = HRTIM_PRELOAD_DISABLED;
  HRTIM_TimerWaveStructureBlue.UpdateGating          = HRTIM_UPDATEGATING_INDEPENDENT;
  HRTIM_TimerWaveStructureBlue.BurstMode             = HRTIM_TIMERBURSTMODE_MAINTAINCLOCK;
  HRTIM_TimerWaveStructureBlue.RepetitionUpdate      = HRTIM_UPDATEONREPETITION_DISABLED;
  HRTIM_TimerWaveStructureBlue.PushPull              = HRTIM_TIMPUSHPULLMODE_DISABLED;
  HRTIM_TimerWaveStructureBlue.FaultEnable           = HRTIM_TIMFAULTENABLE_NONE;
  HRTIM_TimerWaveStructureBlue.FaultLock             = HRTIM_TIMFAULTLOCK_READWRITE;
  HRTIM_TimerWaveStructureBlue.DeadTimeInsertion     = HRTIM_TIMDEADTIMEINSERTION_DISABLED;
  HRTIM_TimerWaveStructureBlue.BalancedIdleAutomaticResume = HRTIM_OUTPUTBIAR_DISABLED;
  HRTIM_TimerWaveStructureBlue.ResetTrigger          = HRTIM_TIMRESETTRIGGER_NONE;
  HRTIM_TimerWaveStructureBlue.ResetUpdate           = HRTIM_TIMUPDATEONRESET_DISABLED;
  HRTIM_TimerWaveStructureBlue.ReSyncUpdate          = HRTIM_TIMERESYNC_UPDATE_UNCONDITIONAL;
  HRTIM_TimerWaveStructureBlue.DelayedProtectionMode = HRTIM_TIMER_A_B_C_DELAYEDPROTECTION_DISABLED;
  HRTIM_TimerWaveStructureBlue.UpdateTrigger         = HRTIM_TIMUPDATETRIGGER_TIMER_A;
  if(HAL_HRTIM_WaveformTimerConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimerWaveStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // ARIS: the basic TIMER A counter period setup
  HRTIM_TimeBaseStructureBlue.Period            = PERIOD; /* 1 period = 4 us = 100% time */
  HRTIM_TimeBaseStructureBlue.RepetitionCounter = 0x00;
  HRTIM_TimeBaseStructureBlue.PrescalerRatio    = HRTIM_PRESCALERRATIO_MUL32;
  HRTIM_TimeBaseStructureBlue.Mode              = HRTIM_MODE_CONTINUOUS;
  if(HAL_HRTIM_TimeBaseConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimeBaseStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }


  // Trigger for the blue DAC sawtooth step, using CMP2
  HRTIM_CompareStructureBlue.AutoDelayedMode    = HRTIM_AUTODELAYEDMODE_REGULAR;
  HRTIM_CompareStructureBlue.AutoDelayedTimeout = 0;
  HRTIM_CompareStructureBlue.CompareValue       = (PERIOD/(SLOW_DAC_STEP_NB));
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                     HRTIM_COMPAREUNIT_2, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }


  // Configure External Event Source 2 
  HRTIM_ExternalEventStructureBlue.Source      = HRTIM_EEV2SRC_COMP4_OUT; 
  HRTIM_ExternalEventStructureBlue.Polarity    = HRTIM_EVENTPOLARITY_HIGH;
  HRTIM_ExternalEventStructureBlue.Sensitivity = HRTIM_EVENTSENSITIVITY_LEVEL;
  HRTIM_ExternalEventStructureBlue.FastMode    = HRTIM_EVENTFASTMODE_ENABLE;
  HRTIM_ExternalEventStructureBlue.Filter      = HRTIM_EVENTFILTER_NONE;
  if(HAL_HRTIM_EventConfig(&HrtimHandle, HRTIM_EVENT_2, &HRTIM_ExternalEventStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure blanking on COMP event to avoid spurious glitch 
  if(HAL_HRTIM_TimerEventFilteringConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, HRTIM_EVENT_2, &HRTIM_TimerEventFilteringCfg) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 3 is used to blank COMP event at the beginning of the period 
  // This is to avoid being reset by spurious glitch 
  HRTIM_CompareStructureBlue.CompareValue       = 0x500; // ARIS: = 1280 periods of 5.44GHz clock = 0.235us  = 1/17th of the counter period (4us)
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                    HRTIM_COMPAREUNIT_3, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  // Compare unit 1 is used to force output of HRTIM few cycles after roll over. 
  // This is to be sure timer output is set despite reset (COMP) event occurring at the very beginning of the period 
  HRTIM_CompareStructureBlue.CompareValue       = 0x100;
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                     HRTIM_COMPAREUNIT_1, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }

  HRTIM_CompareStructureBlue.CompareValue       = 0x20; // led appears off
  //HRTIM_CompareStructure.CompareValue       = 0xFFFF; // led appears on
  if(HAL_HRTIM_WaveformCompareConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A,
                                     HRTIM_COMPAREUNIT_4, &HRTIM_CompareStructureBlue) != HAL_OK)
  {
    Error_Handler();
  }
  

  // Enable the TA1 output 
  if(HAL_HRTIM_WaveformOutputStart(&HrtimHandle, HRTIM_OUTPUT_TA1) != HAL_OK)
  {
    Error_Handler();
  }

  // Configure DAC Reset and Step signal for sawtooth generation 
  if(HAL_HRTIM_TimerDualChannelDacConfig(&HrtimHandle, HRTIM_TIMERINDEX_TIMER_A, &HRTIM_TimerCtl) != HAL_OK)
  {
    Error_Handler();
  }

  // ---------------------------  these are for all HRTIM timers  -------------------------------------------
  // Start all slaves in one shot so that theyre are all synchronised 

  if(HAL_HRTIM_WaveformCounterStart_DMA(&HrtimHandle, HRTIM_TIMERID_TIMER_E | HRTIM_TIMERID_TIMER_F | HRTIM_TIMERID_TIMER_A) != HAL_OK)
  {
    Error_Handler();
  }




  // Aris; Turned this off. No dimming using burst from main controller.
  if(HAL_HRTIM_BurstModeCtl(&HrtimHandle, HRTIM_BURSTMODECTL_DISABLED) != HAL_OK)
  {
    Error_Handler();
  }

}


// TODO: Aris: doesn't look correct. Low priority to check
static void HRTIM_DeConfig(void)
{
  // BUCK LED is OFF 
  HAL_Delay(10);

  // Stop HRTIM A1 waveform generation
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TA1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_A);

  // Stop HRTIM E1 waveform generation
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TE1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_E);

  // Stop HRTIM F1 waveform generation 
  if(HAL_HRTIM_WaveformOutputStop(&HrtimHandle,  HRTIM_OUTPUT_TF1) != HAL_OK)
  {
    Error_Handler();
  }
  HAL_HRTIM_WaveformCounterStop_DMA(&HrtimHandle,  HRTIM_TIMERID_TIMER_F);

  // Stop burst mode and deinitialize HRTIM 
  HAL_HRTIM_BurstModeCtl(&HrtimHandle, HRTIM_BURSTMODECTL_DISABLED);
  HAL_HRTIM_DeInit(&HrtimHandle);
  __HAL_RCC_HRTIM1_CLK_DISABLE();
  __HAL_RCC_HRTIM1_FORCE_RESET();
  HAL_Delay(1);
  __HAL_RCC_HRTIM1_RELEASE_RESET();

  // Deinit GPIO 
  HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6);
  HAL_GPIO_DeInit(GPIOC, GPIO_PIN_8);
  HAL_GPIO_DeInit(GPIOA, GPIO_PIN_8);
}

/******* END OF CONTROLER ************/
