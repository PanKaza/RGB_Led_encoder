/*KAZANTZIDIS PANAGIOTIS 2022*/
#define __ENCODER_C

#include "main.h"
#include "defs.h"
#include "redgreenRGB.h"
#include "blueRGB.h"
#include "controlerRGB.h"
#include "8b_10b_encoder.h"

#include "printf.h"
#include <stdlib.h>
#include <time.h>//for testing


//There arrays correspond to the encoding of 8b-10b
//rd0 -> rd=-1, rd1->rd=1
static uint32_t rd1_5b[32]={
/*00*/0x18,
/*01*/0x22,
/*02*/0x12,
/*03*/0x31,
/*04*/0xA,
/*05*/0x29,
/*06*/0x19,
/*07*/0x7,
/*08*/0x6,
/*09*/0x25,
/*10*/0x15,
/*11*/0x34,
/*12*/0xD,
/*13*/0x2C,
/*14*/0x1C,
/*15*/0x28,
/*16*/0x24,
/*17*/0x23,
/*18*/0x13,
/*19*/0x32,
/*20*/0xB,
/*21*/0x2A,
/*22*/0x1A,
/*23*/0x5,
/*24*/0xC,
/*25*/0x26,
/*26*/0x16,
/*27*/0x9,
/*28*/0xE,
/*29*/0x11,
/*30*/0x21,
/*31*/0x14
};

static uint32_t rd0_5b[32]={
/*00*/0x27,
/*01*/0x1D,
/*02*/0x2D,
/*03*/0x31,
/*04*/0x35,
/*05*/0x29,
/*06*/0x19,
/*07*/0x38,
/*08*/0x39,
/*09*/0x25,
/*10*/0x15,
/*11*/0x34,
/*12*/0xD,
/*13*/0x2C,
/*14*/0x1C,
/*15*/0x17,
/*16*/0x1B,
/*17*/0x23,
/*18*/0x13,
/*19*/0x32,
/*20*/0xB,
/*21*/0x2A,
/*22*/0x1A,
/*23*/0x3A,
/*24*/0x33,
/*25*/0x26,
/*26*/0x16,
/*27*/0x36,
/*28*/0xE,
/*29*/0x2E,
/*30*/0x1E,
/*31*/0x2B
};

static uint32_t rd0_3b[9]={
/*00*/0xB,
/*01*/0x9,
/*02*/0x5,
/*03*/0xC,
/*04*/0xD,
/*05*/0xA,
/*06*/0x6,
/*07a*/0xE,
/*07b*/0x7};

static uint32_t rd1_3b[9]={
/*00*/0x4,
/*01*/0x9,
/*02*/0x5,
/*03*/0x3,
/*04*/0x2,
/*05*/0xA,
/*06*/0x6,
/*07a*/0x1,
/*07b*/0x8};

void printBinary(int num_dig,uint32_t digits) {

    int mult=(1<<(num_dig-1));
    while(mult!=0)
    {
        if(digits&mult)
        {
            printf("1");
        }
        else
        {
            printf("0");
        }
        mult=mult>>1;
    }
}

void calc_new_rd(int *aces,int *zeros,int *parity_num,int *RD,int num_dig,uint32_t digits)
{
    int i,cur_rd=0;
    for (i=0;i<num_dig;i++)
    {
        if((digits&1)==0)
        {
            *zeros+=1;
            cur_rd-=1;
        }
        else
        {
            *aces+=1;
            cur_rd+=1;
        }
        digits=digits>>1;
    }
    *parity_num+=cur_rd;

    if(cur_rd!=0)
    {
        *RD=-*RD;
    }
}

void encode5b_6b(uint32_t p2,int RD,uint32_t *abcdef)
{

    if(RD==-1)
    {
        *abcdef=rd0_5b[p2];
    }
    else
    {
        *abcdef=rd1_5b[p2];
    }
}

void encode3b_4b(uint32_t p1,uint32_t p2,int RD,uint32_t *ghij)
{
    if(RD==-1)
    {   
        if(p1==7)
        {   
            if(p2==17||p2==18||p2==20){
                p1+=1;
            }
            
        }
        *ghij=rd0_3b[p1];
    }
    else
    {
        if(p1==7)
        {   
            if(p2==11||p2==13||p2==14){
                p1+=1;
            }
            
        }
        *ghij=rd1_3b[p1];
    }
}

void split_input(int *p1,int *p2,uint8_t number)
{
    *p1 = number>>5;
    *p2 = number & 0x1f;
}

void check8binput(uint8_t input)
{
    if((input>0xff)||(input<0)){
        printf("Wrong size of input:%d",input);
        exit(0);
    }
}

void decode10_8(int elements,uint32_t encoded_data[],uint32_t decoded_data[])
//this method ensures that all our elements are encoded correctly
{
    int i,j,abcdei=0,fghj=0,edcba=0,hgf=0;
    //printf("Decoding...\n");
    for (i=0;i<elements;i++)
    {
        abcdei=encoded_data[i]>>4;
        fghj=encoded_data[i]&0x0f;
        for(j=0;j<32;j++)
        {
            if(abcdei==rd0_5b[j]||abcdei==rd1_5b[j])
            {
                edcba=j;
                break;
            }
        }
        for(j=0;j<9;j++)
        {
            if(fghj==rd0_3b[j]||fghj==rd1_3b[j])
            {
                if(j==8)
                {
                    j=7;
                }
                hgf=j;
                break;
            }
        }
        decoded_data[i]=(hgf<<5)+edcba;
        //printf("For %ld/dec, ",encoded_data[i]);
        /*
        printBinary(10,encoded_data[i]);
        printf("/bin -> ");

        printBinary(3,hgf);
        printf("-");
        printBinary(5,edcba);
        printf("/bin or %d/dec\n",(hgf<<5)+edcba);
        */
        
    }
    
}

void generate_example(int elements,uint32_t data[])
//this method is here for testing purposes only
{
    int i;
    srand(time(NULL));
    for(i=0;i<elements;i++)
    {
        data[i]=rand()%256;
    }

    //this is for testing all possible 8bit values please change "elements" on main to 0xff
    /*
    for (i=0;i<=0xff;i++)
    {
        data[i]=i;
    }
    */
}

void bits_to_led_data(int elements,uint32_t source[],uint32_t led_data[])
{
    int i,j,word,index=0;
    for(j=0;j<elements;j++)
    {
        word=source[j];
        for(i=0;i<10;i++)
        {
            if((word&0b1000000000)==0b1000000000)
            {
                led_data[index]=0xffff;
            }
            else
            {
                led_data[index]=0x20;
            }
            word=word<<1;
            index++;
        }
    }
}

void compare_data(int elements,uint8_t data[],uint32_t decoded_data[])
{
    int i;
    for(i=0;i<elements;i++)
    {
        if(data[i]!=decoded_data[i])
        {
            printf("Original_data and decoded_data are not the same on %d element, original: %ld, decoded: %ld",i,data[i],decoded_data[i]);
            exit(0);
        }
    }
    //printf("\nSuccessful 8b-10b decoding.");

}

//int global_aces=0;
//int global_zeros=0;

void encode8b_10b(int* RD,uint32_t elements,uint8_t data[],uint32_t encoded_led_data[],uint32_t decoded_data[])
{
    //total number of elements of our data
    uint32_t temp_data[elements];
    int parity_num=0,aces=0,zeros=0;
    int p1=-1,p2=-1;
    uint8_t input;
    uint32_t abcdef,ghij;
    //int data[elements],encoded_data[elements],decoded_data[elements];

    //generate_example(elements,data);// generates random data
    //printf("Encoding has started...");
    int i;
    for (i=0;i<elements;i++){
        input=data[i];

        //check input size
        check8binput(input);

        //split input to p1 and p2
        split_input(&p1,&p2,input);

        //5->6 bit encoding
        encode5b_6b(p2,*RD,&abcdef);

        //calculate the new rd of aces-zeros
        calc_new_rd(&aces,&zeros,&parity_num,RD,6,abcdef);

        //3->4 bit encoding
        encode3b_4b(p1,p2,*RD,&ghij);

        //calculate the new rd of aces-zeros
        calc_new_rd(&aces,&zeros,&parity_num,RD,4,ghij);
        /*
        output prints
        printf("For %ld/dec, ",input);
        printBinary(8,input);
        printf("/bin -> ");

        printBinary(6,abcdef);
        printf("-");
        printBinary(4,ghij);
        printf("\n");

        printf("aces-zeros difference : %d\ncurrent rd: %d\n",parity_num,*RD);
        printf("------------\n");
        output prints
        */

        //save our encoded data to a array
        temp_data[i]=((abcdef<<4)+ghij);
        
    }
    //global_aces=global_aces+aces;
    //global_zeros=global_zeros+zeros;
    //printf("total aces: %d, total zeros: %d",global_aces,global_zeros);
    //printf("\ntotal aces/zeros ratio : %d \n\n",global_aces/global_zeros);


    //lets decode our encoded data
    decode10_8(elements,temp_data,decoded_data);

    //lets compare our original data to our decoded data
    compare_data(elements,data,decoded_data);

    bits_to_led_data(elements,temp_data,encoded_led_data);

    //enable these prints to see exactly the encoded results
    /*
    printf("\nresults for : \n");
    for(i=0;i<elements;i++)
    {
        printf("%ld,",data[i]);
    }
    printf("\n");
    int j=0;
    for(i=0;i<elements*10;i++){
        if(encoded_led_data[i]==0xffff){
            printf("1");
        }
        else if(encoded_led_data[i]==0x20)
        {
            printf("0");
        }
        else{
            printf("error on %ld",encoded_led_data[i]);
        }

        if(j==9){
            printf(",");
            j=0;
        }
        else{
            j++;
        }
    }
    */
}
/*KAZANTZIDIS PANAGIOTIS 2022*/


