
#undef GLOBAL
#ifdef __MAIN_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

/* Includes ------------------------------------------------------------------*/
#include "stm32g4xx_hal.h"


#define LED_RED_PORT GPIOB
#define LED_RED_PIN  GPIO_PIN_5
/* Exported types ------------------------------------------------------------*/
/* Exported constants --------------------------------------------------------*/
/* Exported macro ------------------------------------------------------------*/
/* Exported variables ------------------------------------------------------------*/
/* Demo state machine */

GLOBAL HRTIM_HandleTypeDef  HrtimHandle;

/* Exported functions ------------------------------------------------------- */
GLOBAL void Error_Handler(void);
#endif /* __MAIN_H */

