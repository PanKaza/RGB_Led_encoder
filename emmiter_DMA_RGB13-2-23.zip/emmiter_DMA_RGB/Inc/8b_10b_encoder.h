/*KAZANTZIDIS PANAGIOTIS 2022*/

#undef GLOBAL
#ifdef __ENCODER_C
#define GLOBAL
#else
#define GLOBAL extern
#endif

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __ENCODER_C
#define __ENCODER_C

#ifdef __cplusplus
 extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "main.h"


GLOBAL void encode8b_10b(int* RD,int elements,uint8_t data[],uint32_t encoded_data[],uint32_t decoded_data[]);


#ifdef __cplusplus
}
#endif

#endif

/*KAZANTZIDIS PANAGIOTIS 2022*/
