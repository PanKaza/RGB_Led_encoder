
#ifndef __DEFINES_H
#define __DEFINES_H

#ifdef __cplusplus
 extern "C" {
#endif


// controller
/* PWM frequency 250kHz (4us) with System_clock =170MHz and with Prescaler multiply by 32  */
// Aris: = 21760 = 0x5500
#define PERIOD ((170000 * 32 ) / 250) // 250 /2

/*****************************************************************/
/* Defines for DAC saw tooth generation to limit leds current    */
/*****************************************************************/
/* Maximum led current limitation. Same value for all 3 RBG leds. Unit: mA */
#define MAX_LED_CURRENT        100 // 100


#define BRIGHTNESS_THRESHOLD   100 // 200
// red green
// Defines for DAC saw tooth generation to limit leds current    
//

// Sense resistor value. Same value for all 3 RBG leds . Unit: Ohm 
#define SENSE_RESISTOR           3


// Maximum sense voltage. Same value for all 3 RBG leds. Unit mV
#define MAX_SENSE_VOLTAGE      (MAX_LED_CURRENT * SENSE_RESISTOR)


// DAC sawtooth range in mV . It correspond to slope rate 100 mA / 4us  
// Aris: that the same as MAX_SENSE_VOLTAGE
#define DAC_SAWTOOTH_RANGE   (100 * SENSE_RESISTOR)

// Current should hit sawtooth slope in the middle of the slope. Thus sawtooth peak is current limit + half slope range 
#define MAX_DAC_SAW_PEAK     (MAX_SENSE_VOLTAGE + (DAC_SAWTOOTH_RANGE / 2))

// Fast DAC supports up to 15 Msamples per seconds -> 15MHz/250kHz = 60steps 
#define FAST_DAC_STEP_NB     60

// sawtooth step parameter is 12.4 bit format (12 bits integer part, 4 bits fractional part), thus value is shifted by 4 bits 
// Aris: 2^12=4096, The mult is to convert the range into the full 12 bit resolution. The 4 bits fraction part must be a convention of HAL
//   Then this is divided by 3.3V = 3300mV times the number of steps we can have
//   = 99.29696... = 99 0x63 (or is it 100? 0x64)
#define FAST_DAC_STEP        (((DAC_SAWTOOTH_RANGE * 4096) << 4) / (3300 * FAST_DAC_STEP_NB))

// comment this line to disable debug: output of DAC on GPIO 
// Warning: PB1 used for debug of red DAC (through OPAMP) is already used for Orange led 
#define DEBUG_FAST_DAC


// Slow DAC supports up to 1Msamples per seconds whatever conditions.    
// but in the present circumstances it can be extended.                  
// For RGB led demo due to low load on DAC we use 3Msamples per seconds 
// -> 3MHz/250kHz = 12steps
#define SLOW_DAC_STEP_NB     12 // 12

// sawtooth step parameter is 12.4 bit format (12 bits integer part, 4 bits fractional part), thus value is shifted by 4 bits 
// Aris = 496.48 0x1f0
#define SLOW_DAC_STEP        (((DAC_SAWTOOTH_RANGE * 4096) << 4) / (3300 * SLOW_DAC_STEP_NB)) 



#ifdef __cplusplus
}
#endif

#endif /* __DEFINES_H */


/******** IOANNIS PAPAGEORGIOU 2022 UOI **********/
